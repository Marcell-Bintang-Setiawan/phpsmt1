<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container" style="background-color: white;">

<h1>Kontak</h1>
<h3>Stay in Touch</h3>
<br>

<img src="main/img/apotek.png" alt="" width="20%" style="float: right; margin-right: 30px; " >
<div class="kontak" style="margin-left: 30px;">
    <i class="fas fa-tty"> Telepon</i>
    <p>088812345678</p>
    <i class="fas fa-envelope-open-text"> Email</i>
    <p>example.gmail.com</p>
    <i class="fab fa-instagram"> <b>Instagram</b></i>
    <p>@example</p>
    <i class="fab fa-twitter-square"> <b>Twitter</b></i>
    <p>@example</p>
    <i class="fab fa-twitter-square"> <b>Office</b></i>
    <p>Jl. Raya Tarik, Desa Kemuning, Tarik, Sidoarjo <br>
    Jawa Timur, Indonesia <br>
    61265</p>
</div>


</div>
</body>
</html>
