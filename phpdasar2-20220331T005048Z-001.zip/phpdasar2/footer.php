<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css" integrity="sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp" crossorigin="anonymous">
    <link rel="stylesheet" href="landing.css">
    <title>Document</title>
</head>
<body style="background-color: rgb(230, 230, 230);" >
<div class="container" style="background-color: white;">
<footer>
  <div class="footer">
    <p>APOTEK BINA SEHAT</p>
    <i class="far fa-envelope" style="padding: 20px;" > example.gmail.com</i>  |
    <i class="fas fa-phone-alt" style="padding: 20px;"  > 088812345678</i>  |
    <i class="fab fa-instagram" style="padding: 20px;" >   @example </i> <br><br>
    <p class="copyright" style="font-size: 14px; padding-bottom: 10px;">copyright 2020</p>
  </div>
</footer>

</div>
</body>
</html>