<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<div class="container" style="background-color: white;">
<h1>Tentang</h1>

<img src="main/img/apotek.png" alt="" width="15%" style="margin-left: 40%;">
<p style="padding: 10px;" >Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum nisi esse nam. Veritatis porro eligendi, odio saepe odit natus quas a! Animi fugiat ea hic molestiae facere qui sit quod? Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem fugit unde in maiores, rerum quaerat suscipit mollitia corrupti temporibus maxime natus laudantium consectetur sunt odit impedit nihil facilis, distinctio illum. Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga incidunt in perspiciatis! Placeat iusto expedita temporibus accusamus velit cumque ratione voluptas, quos illo numquam labore aliquam necessitatibus maxime a. Voluptate. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus vel dicta sed repellendus obcaecati, excepturi impedit. Qui, nostrum omnis dolor debitis possimus necessitatibus temporibus dolorum quisquam. Totam dolore eos voluptates!</p>



</div>



</body>
</html>
