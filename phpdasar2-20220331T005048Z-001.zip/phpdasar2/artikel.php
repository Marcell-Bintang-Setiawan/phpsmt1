<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <title>Artikel</title>
    <style>
        #kiri img { float: left; margin: 5px;  }

    </style>
</head>
<body>
<div class="container" style="background-color: white;">
    <h1>Halaman Artikel</h1><br>
<article>
    <div id="kiri">
    <h3>Artikel Satu</h3>
    <img src="main/img/pegawai.png" alt="" width="10%">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta, sint ipsam ut eaque non laboriosam enim quisquam harum. Sit dolores possimus impedit unde perspiciatis eum consequatur voluptas minima dignissimos laborum. Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio officia temporibus aspernatur consequatur accusamus quisquam quos ad ea placeat reprehenderit, omnis quidem natus corporis iusto dignissimos quod, dolores nulla consequuntur!</p>
    </div>
</article>
<br><br>
<article>
    <h3>Artikel Dua</h3>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta, sint ipsam ut eaque non laboriosam enim quisquam harum. Sit dolores possimus impedit unde perspiciatis eum consequatur voluptas minima dignissimos laborum. Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio officia temporibus aspernatur consequatur accusamus quisquam quos ad ea placeat reprehenderit, omnis quidem natus corporis iusto dignissimos quod, dolores nulla consequuntur!</p>
</article>






</div>
</body>
</html>
